from django.shortcuts import render,redirect
from django.http import HttpResponse
from .models import Task
from .forms import TaskForm



def index(request):
    if request.method == 'POST':
        form = Task(request.POST)
        form.save()
        return redirect('/')
    tsk = Task.objects.all()
    form = Task()
    contex = {
        'tsk': tsk,
        'form': form
    }
    return render(request,'index.html', contex)

def add(request):
    if request.method == 'POST':
        form = TaskForm(request.POST)
        form.save()
        return redirect('http://127.0.0.1:8000/')


    form = TaskForm()
    data = {
        'form': form
    }
    return render(request, "add.html", data)
