from django.contrib import admin
from .models import Request

admin.site.register(Request)