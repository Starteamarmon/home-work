slovar: dict = {

}
slovar["klusc"] = 'не клуч'
slovar['klusc'] = "всё таки ключ"
